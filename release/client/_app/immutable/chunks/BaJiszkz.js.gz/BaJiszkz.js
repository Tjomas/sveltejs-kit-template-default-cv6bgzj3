const s=globalThis.__sveltekit_1ppwa44?.base??"",a=globalThis.__sveltekit_1ppwa44?.assets??s??"";export{a,s as b};
