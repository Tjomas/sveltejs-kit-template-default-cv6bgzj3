const s=globalThis.__sveltekit_vbyf5r?.base??"",a=globalThis.__sveltekit_vbyf5r?.assets??s??"";export{a,s as b};
